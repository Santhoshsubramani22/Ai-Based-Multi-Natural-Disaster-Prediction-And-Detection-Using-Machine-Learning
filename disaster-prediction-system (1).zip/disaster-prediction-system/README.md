# AI-Based Multi-Disaster Risk Assessment System

A local Flask + SQLite + scikit-learn demonstration app for exploring the supplied `natural_disaster_ml_dataset_5000.csv`.

## Important limitations
- The supplied CSV contains 5,000 rows and duplicate column names (Pandas will suffix duplicate names such as `.1`). It has environmental/geographical features, seven occurrence labels, and summary labels. `disaster_type` is missing on 1,942 rows and `previous_disaster_type` on 976 rows.
- This is a **dataset-based educational risk-assessment demo**, not an operational early-warning service. The CSV alone does not establish that its records are verified real-world observations, and model scores must not be treated as real-world disaster probabilities.
- Models are trained only for disaster occurrence labels actually present in the CSV. Inputs are selected per disaster and must match the features used by the corresponding model. The UI does not claim official warnings or send external alerts.
- Earthquake/tsunami risk cannot be reliably forecast from a few manually entered measurements. For emergencies, use your local official disaster management agency.

## Setup (Windows PowerShell)
1. Install Python 3.10+.
2. Place `natural_disaster_ml_dataset_5000.csv` in the project `data/` folder.
3. Open PowerShell in this folder:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   py -m pip install --upgrade pip
   pip install -r requirements.txt
   py database/init_db.py
   py ml/train_model.py --data data/natural_disaster_ml_dataset_5000.csv
   py app.py
   ```
4. Open `http://127.0.0.1:5000`.

Linux/macOS: use `python3 -m venv .venv`, `source .venv/bin/activate`, then replace `py` with `python`.

## Pages
Dashboard, prediction, CSV upload/analysis, map, analytics, alerts, history and model performance. Chart.js and Leaflet are loaded from public CDNs; the Python backend does not need paid API keys.

## CSV upload
Upload CSVs up to 10 MB. Upload analysis is exploratory only; uploading a file does not automatically retrain models. For retraining, run `ml/train_model.py` after inspecting the dataset and target labels.

## Tests
Run `pytest -q`.

## Troubleshooting
- `Model unavailable`: run the training command and verify each target column exists with both classes.
- `FileNotFoundError`: verify the CSV path and filename.
- PowerShell activation blocked: run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` for the current terminal only, then activate.
- Chart/map blank: check internet access for CDN/tile resources. The Flask app itself runs locally.


## Analytics, risk map, and department email dispatch

- **Analytics** includes disaster-type counts, risk-level and alert-level distributions, average risk by disaster type, monthly average risk score (when timestamps parse), top districts by average risk score, and missing-value counts.
- **Disaster map** colors dataset markers by risk: red = critical, orange = high, yellow = medium, green = low. Use the filters to inspect disaster type and risk category. Coordinates are those in the supplied dataset, not live verified incident locations.
- **Alert Center** can email a notice to a department after the operator enters a verified recipient and confirms authorization. It does not invent department contact details. Without SMTP settings, no email is sent.

### Configure email (PowerShell session)

Set these environment variables before starting the app. Use an authorized SMTP account and a provider-supported app password; never commit credentials to GitHub. Replace values with your own approved settings:

```powershell
$env:SMTP_HOST = "smtp.example.com"
$env:SMTP_PORT = "587"
$env:SMTP_USER = "your-sending-account@example.com"
$env:SMTP_PASSWORD = "your-app-password"
$env:SMTP_FROM = "your-sending-account@example.com"
python app.py
```

Use the actual SMTP host and port documented by your email provider. A successful dispatch is logged in the Alert Center. If email is not configured or delivery fails, the app reports an error and does not claim that the email was sent. All messages are labelled as assessment notices, not official warnings. This project is educational and must not be used as a substitute for government emergency warning systems.
