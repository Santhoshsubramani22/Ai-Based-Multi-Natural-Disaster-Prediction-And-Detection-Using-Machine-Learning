import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import app

def test_health_endpoint():
    client=app.test_client()
    response=client.get("/api/health")
    assert response.status_code==200
    assert response.json["ok"] is True

def test_predict_rejects_unknown_disaster():
    response=app.test_client().post("/api/predict",json={"disaster":"volcano","values":{}})
    assert response.status_code==400
    assert response.json["ok"] is False

def test_upload_rejects_non_csv():
    response=app.test_client().post("/api/upload",data={"file":("hello.txt",b"hello","text/plain")},content_type="multipart/form-data")
    assert response.status_code==400
