from pathlib import Path
import argparse, json, sys
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report, confusion_matrix
from sklearn.base import clone

ROOT = Path(__file__).resolve().parents[1]
TARGETS = {
    "flood": ("flood_occurrence", ["rainfall_24h_mm","rainfall_7d_mm","river_level_m","river_flow_m3s","soil_moisture_percent","elevation_m","distance_to_river_km","latitude","longitude","temperature_c","humidity_percent"]),
    "earthquake": ("earthquake_occurrence", ["earthquake_depth_km","distance_to_fault_km","ground_acceleration_g","seismic_activity_index","latitude","longitude","elevation_m","previous_disaster_count","historical_risk_score"]),
    "cyclone": ("cyclone_occurrence", ["cyclone_wind_speed_kmh","cyclone_pressure_hpa","cyclone_distance_km","storm_surge_m","sea_level_anomaly_m","air_pressure_hpa","wind_speed_kmh","humidity_percent","latitude","longitude","distance_to_coast_km"]),
    "wildfire": ("wildfire_occurrence", ["temperature_c","humidity_percent","wind_speed_kmh","rainfall_7d_mm","vegetation_dryness_index","fire_weather_index","fuel_moisture_percent","forest_cover_percent","latitude","longitude"]),
    "landslide": ("landslide_occurrence", ["rainfall_24h_mm","rainfall_7d_mm","slope_degree","soil_moisture_percent","soil_saturation_percent","elevation_m","terrain_roughness","landslide_susceptibility","soil_type","latitude","longitude"]),
    "drought": ("drought_occurrence", ["precipitation_anomaly_percent","temperature_anomaly_c","soil_moisture_anomaly","water_storage_index","drought_index","rainfall_7d_mm","temperature_c","humidity_percent","vegetation_index","latitude","longitude"]),
    "tsunami": ("tsunami_occurrence", ["earthquake_magnitude","earthquake_depth_km","distance_to_coast_km","sea_level_anomaly_m","water_level_change_m","latitude","longitude","ground_acceleration_g","seismic_activity_index"]),
}
OUTCOME_COLS = {"flood_occurrence","earthquake_occurrence","cyclone_occurrence","wildfire_occurrence","landslide_occurrence","drought_occurrence","tsunami_occurrence","disaster_occurrence","disaster_type","risk_level","risk_score_0_100","alert_level","severity_1_10","expected_impact_0_100","alert_message","record_id","timestamp","country","state","district","location_name","previous_disaster_type"}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--data", default=str(ROOT/"data"/"natural_disaster_ml_dataset_5000.csv"))
    args=parser.parse_args()
    data_path=Path(args.data)
    if not data_path.exists():
        raise SystemExit(f"Dataset not found: {data_path}. Put the CSV in data/ or pass --data PATH.")
    df=pd.read_csv(data_path, low_memory=False)
    # CSVs can contain duplicate headers; pandas preserves subsequent copies with .1, .2 suffixes.
    artifact_dir=ROOT/"artifacts"; artifact_dir.mkdir(exist_ok=True)
    reports={}
    for disaster,(target,features) in TARGETS.items():
        if target not in df.columns:
            reports[disaster]={"available":False,"reason":f"Target column '{target}' is missing."}; continue
        available=[f for f in features if f in df.columns]
        if len(available)<3:
            reports[disaster]={"available":False,"reason":"Not enough expected feature columns are present."}; continue
        subset=df[available+[target]].copy()
        subset[target]=pd.to_numeric(subset[target],errors="coerce")
        subset=subset[subset[target].isin([0,1])]
        subset=subset.dropna(subset=[target])
        if subset[target].nunique()<2 or len(subset)<30:
            reports[disaster]={"available":False,"reason":"Need at least 30 labelled rows and both classes."}; continue
        X=subset[available].copy()
        y=subset[target].astype(int)
        numeric=[c for c in available if pd.api.types.is_numeric_dtype(X[c])]
        categorical=[c for c in available if c not in numeric]
        transformers=[]
        if numeric:
            transformers.append(("num",Pipeline([("imputer",SimpleImputer(strategy="median"))]),numeric))
        if categorical:
            transformers.append(("cat",Pipeline([("imputer",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore"))]),categorical))
        preprocess=ColumnTransformer(transformers,remainder="drop")
        model=Pipeline([("preprocess",preprocess),("classifier",RandomForestClassifier(n_estimators=160,random_state=42,class_weight="balanced",min_samples_leaf=2))])
        stratify=y if y.value_counts().min()>=2 else None
        Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.2,random_state=42,stratify=stratify)
        model.fit(Xtr,ytr)
        pred=model.predict(Xte)
        precision,recall,f1,_=precision_recall_fscore_support(yte,pred,average="binary",zero_division=0)
        report={"available":True,"target":target,"features":available,"rows":int(len(subset)),"train_rows":int(len(Xtr)),"test_rows":int(len(Xte)),"accuracy":round(float(accuracy_score(yte,pred)),4),"precision":round(float(precision),4),"recall":round(float(recall),4),"f1":round(float(f1),4),"confusion_matrix":confusion_matrix(yte,pred,labels=[0,1]).tolist(),"class_counts":{str(int(k)):int(v) for k,v in y.value_counts().items()}}
        joblib.dump(model,artifact_dir/f"{disaster}_model.joblib")
        reports[disaster]=report
        print(f"{disaster}: trained on {len(subset)} rows; held-out accuracy={report['accuracy']:.3f}")
    (artifact_dir/"model_config.json").write_text(json.dumps(reports,indent=2),encoding="utf-8")
    (artifact_dir/"training_report.json").write_text(json.dumps(reports,indent=2),encoding="utf-8")
    print(f"Saved model configuration to {artifact_dir/'model_config.json'}")
    print("Metrics are a simple random hold-out evaluation, not evidence of operational forecast reliability.")
if __name__=="__main__": main()
