import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from database.init_db import init_db

def test_database_initializes():
    path=init_db()
    assert path.exists()
