from pathlib import Path
import json
import joblib

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
CONFIG_PATH = ARTIFACTS / "model_config.json"

def load_config():
    if not CONFIG_PATH.exists():
        return {}
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

def load_model(disaster):
    path = ARTIFACTS / f"{disaster.lower()}_model.joblib"
    if not path.exists():
        return None
    return joblib.load(path)
