from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "instance" / "disaster_app.db"

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            disaster_type TEXT NOT NULL,
            input_json TEXT NOT NULL,
            prediction TEXT NOT NULL,
            score REAL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            disaster_type TEXT NOT NULL,
            location TEXT,
            level TEXT NOT NULL,
            message TEXT NOT NULL,
            source TEXT NOT NULL,
            created_at TEXT NOT NULL,
            dedupe_key TEXT UNIQUE,
            department TEXT,
            recipient_email TEXT,
            delivery_status TEXT NOT NULL DEFAULT 'IN_APP_ONLY'
        );
        CREATE TABLE IF NOT EXISTS uploads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            rows_count INTEGER NOT NULL,
            columns_count INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );
        """)
        # Add columns safely when upgrading an existing local database.
        existing = {row[1] for row in conn.execute("PRAGMA table_info(alerts)").fetchall()}
        for name, definition in {
            "department": "TEXT",
            "recipient_email": "TEXT",
            "delivery_status": "TEXT NOT NULL DEFAULT 'IN_APP_ONLY'",
        }.items():
            if name not in existing:
                conn.execute(f"ALTER TABLE alerts ADD COLUMN {name} {definition}")
    return DB_PATH

if __name__ == "__main__":
    print(f"Database ready: {init_db()}")
