from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_training_script_exists():
    assert (ROOT/"ml"/"train_model.py").exists()
