from pathlib import Path
from datetime import datetime, timezone
import json, sqlite3, io, os, smtplib, re
from email.message import EmailMessage
import pandas as pd
from flask import Flask, render_template, request, jsonify
from werkzeug.utils import secure_filename
from ml.model_registry import load_config, load_model
from database.init_db import init_db

ROOT=Path(__file__).resolve().parent
DB_PATH=ROOT/"instance"/"disaster_app.db"
UPLOAD_DIR=ROOT/"uploads"; UPLOAD_DIR.mkdir(exist_ok=True)
MAX_UPLOAD=10*1024*1024
ALLOWED={"csv"}
app=Flask(__name__)
app.config["MAX_CONTENT_LENGTH"]=MAX_UPLOAD
app.config["JSON_SORT_KEYS"]=False
init_db()

FEATURES={
"flood":["rainfall_24h_mm","rainfall_7d_mm","river_level_m","river_flow_m3s","soil_moisture_percent","elevation_m","distance_to_river_km","latitude","longitude","temperature_c","humidity_percent"],
"earthquake":["earthquake_depth_km","distance_to_fault_km","ground_acceleration_g","seismic_activity_index","latitude","longitude","elevation_m","previous_disaster_count","historical_risk_score"],
"cyclone":["cyclone_wind_speed_kmh","cyclone_pressure_hpa","cyclone_distance_km","storm_surge_m","sea_level_anomaly_m","air_pressure_hpa","wind_speed_kmh","humidity_percent","latitude","longitude","distance_to_coast_km"],
"wildfire":["temperature_c","humidity_percent","wind_speed_kmh","rainfall_7d_mm","vegetation_dryness_index","fire_weather_index","fuel_moisture_percent","forest_cover_percent","latitude","longitude"],
"landslide":["rainfall_24h_mm","rainfall_7d_mm","slope_degree","soil_moisture_percent","soil_saturation_percent","elevation_m","terrain_roughness","landslide_susceptibility","soil_type","latitude","longitude"],
"drought":["precipitation_anomaly_percent","temperature_anomaly_c","soil_moisture_anomaly","water_storage_index","drought_index","rainfall_7d_mm","temperature_c","humidity_percent","vegetation_index","latitude","longitude"],
"tsunami":["earthquake_magnitude","earthquake_depth_km","distance_to_coast_km","sea_level_anomaly_m","water_level_change_m","latitude","longitude","ground_acceleration_g","seismic_activity_index"]}
LABELS={k:k.title() for k in FEATURES}
SAFETY={
"flood":"Move away from floodwater; follow official evacuation instructions.",
"earthquake":"During shaking, Drop, Cover, and Hold On; follow local emergency guidance.",
"cyclone":"Follow official cyclone bulletins; shelter away from windows and coastal surge zones.",
"wildfire":"Follow evacuation orders; avoid smoke and do not enter active fire areas.",
"landslide":"Move away from slopes and channels showing movement; follow local alerts.",
"drought":"Follow local water-safety and conservation guidance.",
"tsunami":"If you are coastal and feel a strong/long earthquake, move to high ground immediately and follow official tsunami warnings."}
def now(): return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
def db():
    con=sqlite3.connect(DB_PATH); con.row_factory=sqlite3.Row; return con
def json_error(message,status=400): return jsonify({"ok":False,"error":message}),status
def dataset_path():
    p=ROOT/"data"/"natural_disaster_ml_dataset_5000.csv"
    return p if p.exists() else None
def get_dataset():
    p=dataset_path()
    if not p: return None
    try: return pd.read_csv(p,low_memory=False)
    except Exception: return None
@app.get("/")
def index():
    with db() as con:
        counts={"predictions":con.execute("SELECT COUNT(*) FROM predictions").fetchone()[0],"alerts":con.execute("SELECT COUNT(*) FROM alerts").fetchone()[0],"uploads":con.execute("SELECT COUNT(*) FROM uploads").fetchone()[0]}
    cfg=load_config()
    return render_template("index.html",counts=counts,models=sum(1 for x in cfg.values() if x.get("available")),dataset=dataset_path() is not None)
@app.get("/predict")
def predict_page(): return render_template("predict.html",features=FEATURES)
@app.get("/upload")
def upload_page(): return render_template("upload.html")
@app.get("/map")
def map_page(): return render_template("map.html")
@app.get("/analytics")
def analytics_page(): return render_template("analytics.html")
@app.get("/alerts")
def alerts_page(): return render_template("alerts.html")
@app.get("/history")
def history_page(): return render_template("history.html")
@app.get("/model-performance")
def model_page(): return render_template("model_performance.html")
@app.get("/about")
def about_page(): return render_template("about.html")
@app.get("/api/health")
def health(): return jsonify({"ok":True,"dataset_available":dataset_path() is not None,"models_trained":len([x for x in load_config().values() if x.get("available")])})
@app.get("/api/model/metrics")
def metrics(): return jsonify(load_config())
@app.get("/api/history")
def history():
    with db() as con: rows=con.execute("SELECT * FROM predictions ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([dict(r) for r in rows])
@app.get("/api/alerts")
def alerts():
    with db() as con: rows=con.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([dict(r) for r in rows])
@app.get("/api/map/risks")
def map_risks():
    df=get_dataset()
    if df is None or not {"latitude","longitude"}.issubset(df.columns): return jsonify([])
    cols=[c for c in ["record_id","latitude","longitude","disaster_type","risk_level","alert_level","risk_score_0_100","severity_1_10","expected_impact_0_100","location_name","district","state","country","timestamp","alert_message"] if c in df.columns]
    points=df[cols].dropna(subset=["latitude","longitude"]).copy()
    points=points[pd.to_numeric(points.latitude,errors="coerce").between(-90,90)&pd.to_numeric(points.longitude,errors="coerce").between(-180,180)]
    # Keep the highest-risk 1,500 points so the browser remains responsive.
    if "risk_score_0_100" in points:
        points["risk_score_0_100"]=pd.to_numeric(points["risk_score_0_100"],errors="coerce")
        points=points.sort_values("risk_score_0_100",ascending=False,na_position="last")
    points=points.head(1500)
    return jsonify(points.where(pd.notna(points),None).to_dict(orient="records"))
@app.get("/api/dataset/summary")
def dataset_summary():
    df=get_dataset()
    if df is None: return jsonify({"available":False,"message":"Place the supplied CSV in data/natural_disaster_ml_dataset_5000.csv."})
    return jsonify(summarize(df))
def summarize(df):
    return {"available":True,"rows":int(df.shape[0]),"columns":int(df.shape[1]),"column_names":[str(c) for c in df.columns],"dtypes":{str(c):str(t) for c,t in df.dtypes.items()},"missing":{str(k):int(v) for k,v in df.isna().sum().items() if v},"duplicates":int(df.duplicated().sum()),"describe":json.loads(df.describe(include="all").fillna("").to_json())}
@app.get("/api/analytics")
def analytics():
    df=get_dataset()
    if df is None: return jsonify({"available":False,"message":"Dataset not found."})
    result={"available":True,"rows":len(df),"columns":len(df.columns),"missing":{str(k):int(v) for k,v in df.isna().sum().items() if v},"duplicates":int(df.duplicated().sum())}
    for c in ["disaster_type","risk_level","alert_level"]:
        if c in df: result[c]={str(k):int(v) for k,v in df[c].fillna("Missing").value_counts().items()}
    if "risk_score_0_100" in df:
        scores=pd.to_numeric(df["risk_score_0_100"],errors="coerce").dropna()
        result["risk_score_stats"]={"mean":round(float(scores.mean()),2) if len(scores) else 0,"median":round(float(scores.median()),2) if len(scores) else 0,"min":round(float(scores.min()),2) if len(scores) else 0,"max":round(float(scores.max()),2) if len(scores) else 0}
    if {"disaster_type","risk_score_0_100"}.issubset(df.columns):
        temp=df.assign(risk_score_0_100=pd.to_numeric(df["risk_score_0_100"],errors="coerce"))
        result["risk_by_disaster"]={str(k):round(float(v),2) for k,v in temp.groupby("disaster_type")["risk_score_0_100"].mean().dropna().sort_values(ascending=False).items()}
    if {"timestamp","risk_score_0_100"}.issubset(df.columns):
        temp=df.assign(_date=pd.to_datetime(df["timestamp"],errors="coerce"),risk_score_0_100=pd.to_numeric(df["risk_score_0_100"],errors="coerce"))
        temp=temp.dropna(subset=["_date","risk_score_0_100"])
        if len(temp):
            monthly=temp.groupby(temp["_date"].dt.to_period("M"))["risk_score_0_100"].mean().sort_index().tail(24)
            result["monthly_risk"]={str(k):round(float(v),2) for k,v in monthly.items()}
    if {"district","risk_score_0_100"}.issubset(df.columns):
        temp=df.assign(risk_score_0_100=pd.to_numeric(df["risk_score_0_100"],errors="coerce"))
        top=temp.groupby("district")["risk_score_0_100"].mean().dropna().sort_values(ascending=False).head(10)
        result["top_districts"]={str(k):round(float(v),2) for k,v in top.items()}
    numeric=df.select_dtypes(include="number")
    result["numeric_means"]={str(k):round(float(v),3) for k,v in numeric.mean(numeric_only=True).items() if pd.notna(v)}
    return jsonify(result)
@app.post("/api/upload")
def upload():
    f=request.files.get("file")
    if not f or not f.filename: return json_error("Choose a CSV file first.")
    filename=secure_filename(f.filename)
    if not filename or filename.rsplit(".",1)[-1].lower() not in ALLOWED: return json_error("Only .csv files are supported.")
    raw=f.read(MAX_UPLOAD+1)
    if len(raw)>MAX_UPLOAD: return json_error("File exceeds the 10 MB upload limit.")
    try:
        df=pd.read_csv(io.BytesIO(raw),low_memory=False)
        if df.empty or len(df.columns)==0: return json_error("CSV contains no usable rows or columns.")
    except Exception as exc: return json_error(f"Could not parse CSV: {str(exc)[:180]}")
    with db() as con:
        con.execute("INSERT INTO uploads(filename,rows_count,columns_count,created_at) VALUES(?,?,?,?)",(filename,len(df),len(df.columns),now()))
    return jsonify({"ok":True,"filename":filename,"summary":summarize(df),"preview":df.head(10).where(pd.notna(df.head(10)),None).to_dict(orient="records"),"message":"Analyzed successfully. This upload does not retrain the prediction models."})
@app.post("/api/predict")
def make_prediction():
    body=request.get_json(silent=True)
    if not isinstance(body,dict): return json_error("Send a JSON object.")
    disaster=str(body.get("disaster","")).strip().lower()
    if disaster not in FEATURES: return json_error("Select one of the supported disaster types.")
    config=load_config().get(disaster,{})
    model=load_model(disaster) if config.get("available") else None
    if model is None: return json_error("A suitable trained model is unavailable. Add the dataset and run: py ml/train_model.py",503)
    values=body.get("values")
    if not isinstance(values,dict): return json_error("Parameter values must be an object.")
    required=config.get("features",[])
    missing=[f for f in required if f not in values or values[f] in ("",None)]
    if missing: return json_error("Enter values for the required model features: "+", ".join(missing))
    row={}
    for feature in required:
        val=values[feature]
        if feature=="soil_type": row[feature]=str(val)
        else:
            try: row[feature]=float(val)
            except (TypeError,ValueError): return json_error(f"{feature} must be numeric.")
            if not pd.notna(row[feature]): return json_error(f"{feature} must be a finite number.")
    if "latitude" in row and not -90<=row["latitude"]<=90: return json_error("Latitude must be between -90 and 90.")
    if "longitude" in row and not -180<=row["longitude"]<=180: return json_error("Longitude must be between -180 and 180.")
    try:
        frame=pd.DataFrame([row],columns=required)
        pred=int(model.predict(frame)[0])
        score=None
        if hasattr(model,"predict_proba"):
            score=round(float(model.predict_proba(frame)[0][list(model.named_steps["classifier"].classes_).index(1)]),4)
        label="Occurrence label predicted by the trained model" if pred==1 else "No occurrence label predicted by the trained model"
        timestamp=now()
        with db() as con:
            con.execute("INSERT INTO predictions(disaster_type,input_json,prediction,score,created_at) VALUES(?,?,?,?,?)",(disaster,json.dumps(row),str(pred),score,timestamp))
            if pred==1:
                key=f"{disaster}:{json.dumps(row,sort_keys=True)}"
                con.execute("INSERT OR IGNORE INTO alerts(disaster_type,location,level,message,source,created_at,dedupe_key) VALUES(?,?,?,?,?,?,?)",(disaster,str(row.get("location_name","Not supplied")),"MODEL NOTICE",f"Model classified this input as a positive {disaster} occurrence label. This is not an official warning.", "Local ML model",timestamp,key))
        return jsonify({"ok":True,"disaster":disaster,"prediction":pred,"label":label,"model_score":score,"score_note":"Model class score, not a calibrated real-world probability.","created_at":timestamp,"precautions":SAFETY[disaster],"limitations":"Educational dataset-based classification only. Not an operational forecast or official warning."})
    except Exception as exc:
        app.logger.exception("Prediction failed")
        return json_error(f"Prediction could not be completed: {str(exc)[:200]}",500)

@app.post("/api/alerts/dispatch")
def dispatch_alert():
    body=request.get_json(silent=True)
    if not isinstance(body,dict): return json_error("Send a valid alert form.")
    department=str(body.get("department","")).strip()
    recipient=str(body.get("recipient_email","")).strip()
    disaster=str(body.get("disaster_type","General risk assessment")).strip()[:80]
    location=str(body.get("location","")).strip()[:180]
    level=str(body.get("level","ORANGE")).strip().upper()
    message=str(body.get("message","")).strip()[:1500]
    confirmed=body.get("confirmed") is True
    if not department or not recipient or not location or not message:
        return json_error("Department, recipient email, location, and message are required.")
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+",recipient):
        return json_error("Enter a valid department email address.")
    if not confirmed:
        return json_error("Confirm that the recipient is verified and the notice is authorized before sending.")
    # Actual email is sent only when the operator explicitly configures SMTP settings.
    host=os.getenv("SMTP_HOST","").strip()
    user=os.getenv("SMTP_USER","").strip()
    password=os.getenv("SMTP_PASSWORD","")
    sender=os.getenv("SMTP_FROM",user).strip()
    try: port=int(os.getenv("SMTP_PORT","587"))
    except ValueError: return json_error("SMTP_PORT must be a valid port number.",500)
    if not (host and user and password and sender):
        return jsonify({"ok":False,"error":"Email delivery is not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, and SMTP_FROM in your environment; no email was sent."}),503
    subject=f"[ASSESSMENT NOTICE - NOT OFFICIAL WARNING] {level}: {disaster}"
    body_text=(f"DISASTER RISK ASSESSMENT NOTICE\n\nThis is a dataset/model-based assessment notice, not an official emergency warning. Verify with authorized monitoring agencies before taking action.\n\nDepartment: {department}\nDisaster type: {disaster}\nAssessment level: {level}\nLocation: {location}\n\nDetails: {message}\n\nGenerated by a local educational disaster-risk assessment application. Dataset provenance and current conditions must be independently verified.")
    email=EmailMessage(); email["Subject"]=subject; email["From"]=sender; email["To"]=recipient; email.set_content(body_text)
    try:
        with smtplib.SMTP(host,port,timeout=15) as server:
            server.starttls(); server.login(user,password); server.send_message(email)
    except Exception as exc:
        app.logger.exception("Department email delivery failed")
        return json_error(f"Email delivery failed; no successful dispatch was confirmed. Check SMTP settings. ({str(exc)[:120]})",502)
    timestamp=now()
    with db() as con:
        con.execute("INSERT INTO alerts(disaster_type,location,level,message,source,created_at,department,recipient_email,delivery_status) VALUES(?,?,?,?,?,?,?,?,?)",(disaster,location,level,message,"SMTP email",timestamp,department,recipient,"SENT"))
    return jsonify({"ok":True,"message":f"Assessment notice emailed to {department} ({recipient}).","delivery_status":"SENT","created_at":timestamp})

@app.errorhandler(413)
def too_large(_): return json_error("Upload exceeds the 10 MB limit.",413)
if __name__=="__main__": app.run(debug=False,host="127.0.0.1",port=5000)
